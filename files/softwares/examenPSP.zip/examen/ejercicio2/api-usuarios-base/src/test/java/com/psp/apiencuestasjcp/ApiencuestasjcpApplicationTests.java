package com.psp.apiencuestasjcp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiencuestasjcpApplicationTests {

	@Test
	void contextLoads() {
	}

}

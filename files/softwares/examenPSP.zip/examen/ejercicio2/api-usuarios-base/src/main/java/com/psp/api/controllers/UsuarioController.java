package com.psp.api.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.psp.api.dtos.CreateUsuarioDto;
import com.psp.api.dtos.EditUsuarioDto;
import com.psp.api.dtos.GetUsuarioDto;
import com.psp.api.entities.Usuario;
import com.psp.api.exceptions.PasswordException;
import com.psp.api.exceptions.UsuarioNotFoundException;
import com.psp.api.mappers.UsuarioMapper;
import com.psp.api.repositories.UsuarioRepository;

import jakarta.validation.Valid;

// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;

@RestController
class UsuarioController {

  // Logger para imprimir por pantalla trazas (log.info(string))
  // private static final Logger log =
  // LoggerFactory.getLogger(EmpleadoController.class);

  // Repositorio de usuarios
  private final UsuarioRepository repository;

  // Mapper de usuarios
  private final UsuarioMapper mapper;

  UsuarioController(UsuarioRepository repository, UsuarioMapper mapper) {
    this.repository = repository;
    this.mapper = mapper;
  }

  // Obtener lista de usuarios
  @GetMapping("/usuarios")
  List<GetUsuarioDto> getUsuarios() {
    List<Usuario> usuarios = repository.findAll();
    List<GetUsuarioDto> usuariosF = new ArrayList<GetUsuarioDto>();
    for (Usuario usuario : usuarios) {
      usuariosF.add(new GetUsuarioDto(usuario));
    }
    return usuariosF;
  }

  // Crear un nuevo usuario
  @PostMapping("/usuarios")
  @ResponseStatus(code = HttpStatus.CREATED)
  GetUsuarioDto postUsuario(@NonNull @Valid @RequestBody CreateUsuarioDto nuevoUsuarioDto) {
    if (nuevoUsuarioDto.getPassword().length() <5){
      throw new PasswordException();
    }
    Usuario usuario = mapper.toUsuario(nuevoUsuarioDto);
    return new GetUsuarioDto(repository.save(Objects.requireNonNull(usuario)));
  }

  // Obtener un usuario por su ID (si existe)
  @GetMapping("/usuarios/{id}")
  GetUsuarioDto getUsuarioById(@NonNull @PathVariable Integer id) {
    return new GetUsuarioDto(repository
        .findById(id)
        .orElseThrow(() -> new UsuarioNotFoundException(id)));
  }

  // Actualizar un empleado existente (si no existe se crea uno nuevo)
 @PatchMapping("/usuarios/{id}")
  GetUsuarioDto putUsuarioById(
      @NonNull @Valid @PathVariable Integer id,
      @NonNull @Valid @RequestBody EditUsuarioDto nuevoUsuario) {

    Usuario u = repository
        .findById(id)
        .orElseThrow(() -> new UsuarioNotFoundException(id));
      u.setActivo(nuevoUsuario.getActivo());
      repository.save(u);
     return new GetUsuarioDto(u);
     

  }

  // Borrar un empleado por su ID
  @DeleteMapping("/usuarios/{id}")
  @ResponseStatus(HttpStatus.NO_CONTENT)
  void deleteEmpleadoById(@NonNull @PathVariable Integer id) {
    repository
        .findById(id)
        .orElseThrow(() -> new UsuarioNotFoundException(id));
    repository.deleteById(id);
  }
}

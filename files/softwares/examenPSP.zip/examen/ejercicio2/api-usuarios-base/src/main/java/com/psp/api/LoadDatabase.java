package com.psp.api;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.psp.api.entities.Usuario;

import com.psp.api.repositories.UsuarioRepository;

@Configuration
class LoadDatabase {

  private static final Logger log = LoggerFactory.getLogger(LoadDatabase.class);

  @Bean
  CommandLineRunner initDatabase(UsuarioRepository usuarioRepository) {

    Usuario usuario1 = new Usuario("MariaPerez@gmail.com", "aaaaa", new Date(), false);
    Usuario usuario2 = new Usuario("CarlosSantos@gmail.com", "bbbbb", new Date(),true);
    Usuario usuario3 = new Usuario("TeresaFidalgo@gmail.com", "ccccc",  new Date(),false);

    return args -> {
      log.info("Preloading " + usuarioRepository.save(usuario1));
      log.info("Preloading " + usuarioRepository.save(usuario2));
      log.info("Preloading " + usuarioRepository.save(usuario3));

    };
  }
}


package com.psp.api.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.psp.api.entities.Usuario;

public interface UsuarioRepository
  extends JpaRepository<Usuario, Integer> {

}



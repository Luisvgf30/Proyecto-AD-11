package com.psp.api.advices;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.psp.api.exceptions.PasswordException;
import com.psp.api.exceptions.UsuarioNotFoundException;

@RestControllerAdvice
class UsuarioExceptionAdvice {
  
  @ExceptionHandler(UsuarioNotFoundException.class)
  @ResponseStatus(code = HttpStatus.NOT_FOUND)
  String usuarioNotFoundHandler(UsuarioNotFoundException ex) {
    return ex.getMessage();
  }

  @ExceptionHandler(PasswordException.class)
  @ResponseStatus(code = HttpStatus.UNPROCESSABLE_ENTITY)
  String PasswordHandler(PasswordException ex) {
    return ex.getMessage();
  }
}


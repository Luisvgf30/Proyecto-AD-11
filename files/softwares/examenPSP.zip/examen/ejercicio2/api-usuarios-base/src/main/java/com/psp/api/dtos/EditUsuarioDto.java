package com.psp.api.dtos;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class EditUsuarioDto {

  @NotNull
  private Boolean activo;

  public EditUsuarioDto() {
  }

  public EditUsuarioDto(Boolean activo) {
    this.activo = activo;
  }
}

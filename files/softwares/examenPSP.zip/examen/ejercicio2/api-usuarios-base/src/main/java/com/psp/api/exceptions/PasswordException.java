package com.psp.api.exceptions;

public class PasswordException extends RuntimeException {

  public PasswordException() {
    super("La Contraseña debe ser de minimo 5");
  }
}

package com.psp.api.mappers;

import java.util.Date;

import org.springframework.stereotype.Component;

import com.psp.api.dtos.CreateUsuarioDto;
import com.psp.api.entities.Usuario;

import io.micrometer.common.lang.NonNull;

@Component
public class UsuarioMapper {
  @NonNull
  public Usuario toUsuario(@NonNull CreateUsuarioDto usuarioDto) {
    return new Usuario(
        usuarioDto.getEmail(),
        usuarioDto.getPassword(),
        new Date(),
        true);
  }
}


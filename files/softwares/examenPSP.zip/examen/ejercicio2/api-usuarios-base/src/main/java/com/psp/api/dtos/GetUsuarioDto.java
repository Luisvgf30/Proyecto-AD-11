package com.psp.api.dtos;

import java.util.Date;

import com.psp.api.entities.Usuario;

import lombok.Data;

@Data
public class GetUsuarioDto {
    
  private Integer id;
  private String email;
  private Date fechaApertura;
  private Boolean activo;

  public GetUsuarioDto() {}

  public GetUsuarioDto(Usuario usuario){
    this.id = usuario.getId();
    this.email = usuario.getEmail();
    this.fechaApertura = usuario.getFechaApertura();
    this.activo = usuario.getActivo();
  }
}

package com.psp.api.entities;

import java.util.Date;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Entity
@Data
public class Usuario {

    @Id
    @GeneratedValue
    private Integer id;

    @NotBlank
    private String email;

    @NotBlank
    @Length(min=5)
    private String password;

    @NotNull
    @JsonFormat(pattern = "dd/MM/yyyy")
    @Temporal(TemporalType.DATE)
    private Date fechaApertura;

    private Boolean activo;

    public Usuario(){}

    public Usuario(String email, String password, Date fechaApertura, Boolean activo){

        this.email = email;
        this.password = password;
        this.fechaApertura = fechaApertura;
        this.activo = activo;
    }
}

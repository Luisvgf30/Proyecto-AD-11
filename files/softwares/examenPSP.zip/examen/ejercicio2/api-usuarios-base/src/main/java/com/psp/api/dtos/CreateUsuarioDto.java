package com.psp.api.dtos;

import java.util.Date;

import org.hibernate.validator.constraints.Length;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.psp.api.exceptions.PasswordException;

import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CreateUsuarioDto {
  @NotBlank(message = "email es obligatorio")
  private String email;

  @JsonFormat(pattern = "dd/MM/yyyy")
  @Temporal(TemporalType.DATE)
  private Date fechaApertura;

  @NotBlank(message = "password es obligatoria")
  private String password;

  private Boolean activo;

  public CreateUsuarioDto() {
  }

  public CreateUsuarioDto(String email, String password, Date fechaApertura, Boolean activo) {
    this.email = email;
    this.password = password;
    this.fechaApertura = fechaApertura;
    this.activo = activo;
  }
}

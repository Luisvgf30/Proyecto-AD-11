
public class Tarea {
    private String orden;
    private String operador1;
    private String operador2;

    public Tarea(String orden, String operador1, String operador2) {
        this.orden = orden;
        this.operador1 = operador1;
        this.operador2 = operador2;
    }

    public String getOrden() {
        return orden;
    }

    public void setOrden(String orden) {
        this.orden = orden;
    }

    public String getOperador1() {
        return operador1;
    }

    public void setOperador1(String operador1) {
        this.operador1 = operador1;
    }

    public String getOperador2() {
        return operador2;
    }

    public void setOperador2(String operador2) {
        this.operador2 = operador2;
    }

    @Override
    public String toString() {
        return "Tarea [orden=" + orden + ", operador1=" + operador1 + ", operador2=" + operador2 + "]";
    }

}

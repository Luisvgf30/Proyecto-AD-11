import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

import com.google.gson.Gson;

public class Servicio implements Runnable {
    Gson gson = new Gson();
    Socket clienteConectado = null;
    float ans = 0;

    public Servicio(Socket clienteConectado) {
        this.clienteConectado = clienteConectado;
    }

    public static int calcularSumatorio(int n) {
        int suma = 0;
        for (int i = 0; i <= n; i++) {
            suma += i;
        }
        return suma;
    }

    @Override
    public void run() {
        String nombreHilo = Thread.currentThread().getName();
        Tarea tarea = null;
        System.out.println(nombreHilo + "\tCLIENTE conectado.....");
        try {
            // Declaración de flujos de entrada y salida
            InputStream entrada = clienteConectado.getInputStream();
            OutputStream salida = clienteConectado.getOutputStream();
            DataInputStream flujoEntrada = new DataInputStream(entrada);
            DataOutputStream flujoSalida = new DataOutputStream(salida);

            boolean correcto = false;
            // Enviar instrucciones al cliente
            flujoSalida.writeUTF("Escribe la petición con el siguiente formato \"CODIGO A B\"");
            flujoSalida.writeUTF("CODIGO PUEDE SER [SUMA,RESTA,MULTI,DIVI,END]");
            flujoSalida.writeUTF("A y B son números enteros (o ANS)");
            do {
                // Recibir respuesta del cliente
                try {
                    String tareaJson = flujoEntrada.readUTF();
                    tarea = gson.fromJson(tareaJson, Tarea.class);
                    switch (tarea.getOrden()) {

                        case "suma":
                            float suma1;
                            float suma2;
                            System.out.println(tarea.toString());

                            if (tarea.getOperador1().equals("ans")) {
                                suma1 = ans;
                            } else {
                                suma1 = Integer.parseInt(tarea.getOperador1());
                            }
                            if (tarea.getOperador2().equals("ans")) {
                                suma2 = ans;
                            } else {
                                suma2 = Integer.parseInt(tarea.getOperador2());
                            }
                            ans = suma1 + suma2;
                            flujoSalida.writeFloat(ans);
                            break;
                        case "resta":
                            float resta1;
                            float resta2;
                            System.out.println(tarea.toString());

                            if (tarea.getOperador1().equals("ans")) {
                                resta1 = ans;
                            } else {
                                resta1 = Integer.parseInt(tarea.getOperador1());
                            }
                            if (tarea.getOperador2().equals("ans")) {
                                resta2 = ans;
                            } else {
                                resta2 = Integer.parseInt(tarea.getOperador2());
                            }
                            ans = resta1 - resta2;
                            flujoSalida.writeFloat(ans);
                            break;
                            
                        case "multi":
                            float multi1;
                            float multi2;
                            System.out.println(tarea.toString());

                            if (tarea.getOperador1().equals("ans")) {
                                multi1 = ans;
                            } else {
                                multi1 = Integer.parseInt(tarea.getOperador1());
                            }
                            if (tarea.getOperador2().equals("ans")) {
                                multi2 = ans;
                            } else {
                                multi2 = Integer.parseInt(tarea.getOperador2());
                            }
                            ans = multi1 * multi2;
                            flujoSalida.writeFloat(ans);
                            break;

                        case "divi":
                        float divi1;
                        float divi2;
                        System.out.println(tarea.toString());

                        if (tarea.getOperador1().equals("ans")) {
                            divi1 = ans;
                        } else {
                            divi1 = Integer.parseInt(tarea.getOperador1());
                        }
                        if (tarea.getOperador2().equals("ans")) {
                            divi2 = ans;
                        } else {
                            divi2 = Integer.parseInt(tarea.getOperador2());
                        }
                        ans = divi1 / divi2;
                        flujoSalida.writeFloat(ans);
                            break;

                        case "end":
                            flujoSalida.writeUTF("¡ADIOS!");
                            correcto = true;
                            System.out.println(nombreHilo + "\tCLIENTE desconectado.....");
                            break;
                    }
                } catch (NumberFormatException e) {
                    flujoSalida.writeFloat(0);
                }
            } while (!correcto);

            // Cerrar sockets y flujos de entrada y salida
            entrada.close();
            flujoEntrada.close();
            salida.close();
            flujoSalida.close();
            clienteConectado.close();

        } catch (IOException e) {
            System.out.println("Error de conexión inesperado");
        }
    }
}

import java.io.*;
import java.net.*;
import java.util.Scanner;

import com.google.gson.Gson;

/**
 * Clase Cliente
 * 
 * Cliente que contacta con el servidor para enviar un numero entero positivo.
 * 
 */
public class Cliente {

  private static Tarea tarea;

  public static void main(String[] args) {
    try {
      Gson gson = new Gson();
      String host = "localhost"; // dirección remota
      int puerto = 6000; // puerto remoto

      System.out.println("CLIENTE INICIADO....");
      Socket cliente = new Socket(host, puerto);

      DataOutputStream flujoSalida = new DataOutputStream(cliente.getOutputStream());
      DataInputStream flujoEntrada = new DataInputStream(cliente.getInputStream());

      Scanner sc = new Scanner(System.in);
      System.out.println(flujoEntrada.readUTF());
      System.out.println(flujoEntrada.readUTF());
      System.out.println(flujoEntrada.readUTF());
      String[] partes;
      do {
        // Enviar un comando al servidorEND
        String respuesta = sc.nextLine();
        partes = respuesta.trim().toLowerCase().split(" ");

        if (!partes[0].equals("END") && partes.length == 3) {
          tarea = new Tarea(partes[0], partes[1], partes[2]);
        } else {
          tarea = new Tarea(partes[0], "1", "1");
        }

        flujoSalida.writeUTF(gson.toJson(tarea));
        switch (partes[0]) {
          case "suma", "resta", "multi", "divi":
            System.out.println(flujoEntrada.readFloat());
            break;
          case "end":
            System.out.println(flujoEntrada.readUTF());
            break;
          default:
            System.out.println("Comando " + tarea.getOrden() + " no admitida");
            break;
        }

      } while (!partes[0].equals("end"));

      sc.close();

      // CERRAR STREAMS Y SOCKETS
      flujoEntrada.close();
      flujoSalida.close();
      cliente.close();

    } catch (EOFException e) {
      System.out.println("Hubo un error de conexión inesperado");
    } catch (IOException e) {
      System.out.println("Hubo un error de I/O inesperado");
    }

  }

}
import java.io.*;
import java.net.*;
/**
 * Clase Servidor
 * 
 * Es un servidor que puede atender muchos clientes
 */
public class Servidor {

  public static void main(String[] arg) throws IOException {
    int numeropuerto = 6000; // puerto
    try (ServerSocket servidor = new ServerSocket(numeropuerto)) {
      for (int i = 0; true; i++) {
        Socket clienteConectado = servidor.accept(); // servidor esperando a que se conecte un cliente

        // cuando un cliente se conecta, el servidor lanza un hilo
        // para atender al cliente
        Servicio s = new Servicio(clienteConectado);
        Thread t = new Thread(s);
        t.setName("S-" + i);
        t.start();
      }
    } catch (Exception e) {
      System.out.println("Error");
    }

    // servidor.close();
  }

}